# Mera AI Assistant — mobile-only APK build kit

This kit is for building the starter Flutter app using a cloud build service from an Android phone. It does not contain a finished production AI backend.

## Files in this kit
- `mera_ai_assistant_starter.zip`: the Flutter starter source project
- `codemagic.yaml`: cloud build instructions for a debug APK
- `PHONE_STEPS.txt`: beginner steps

## Important
The first APK is a test/debug build of the starter interface. Real AI chat, image generation, and video generation require provider APIs and a secure backend. Do not place API keys in the mobile app.
